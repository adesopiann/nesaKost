import { initLandingAnimations } from './animations/landing.js';
import { initGuestMotion } from './animations/guest-motion.js';

// Public guest pages share a lightweight Motion layer.
// Page-specific selectors keep the animation scope explicit.
if (document.querySelector('[data-guest-motion]')) {
    initGuestMotion();
}

if (document.querySelector('[data-page="landing"]')) {
    initLandingAnimations();
}
