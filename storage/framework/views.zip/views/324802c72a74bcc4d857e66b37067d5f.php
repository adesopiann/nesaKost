<?php $__env->startSection('main'); ?>

<div class="space-y-6 text-slate-800">
    <?php echo $__env->make('pages.owner.branches.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="flex flex-col gap-4 rounded-xl bg-white p-6 shadow-sm md:flex-row md:items-center md:justify-between">
        <div>
            <h1 class="text-2xl font-bold">Data Cabang Kos</h1>
            <p class="mt-1 max-w-2xl text-sm text-slate-500">Kelola informasi cabang properti kos, kapasitas kamar, fasilitas umum, dan informasi lokasi secara terpusat.</p>
        </div>
        <a href="<?php echo e(route('owner.branches.create')); ?>" class="inline-flex items-center justify-center rounded-lg bg-blue-900 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-800">
            <span class="mr-2 text-lg">+</span> Tambah Cabang Kos
        </a>
    </section>

    <section class="grid gap-4 md:grid-cols-3">
        <div class="rounded-xl bg-white p-5 shadow-sm">
            <p class="text-sm text-slate-500">Total Cabang Kos</p>
            <div class="mt-3 flex items-end justify-between">
                <p class="text-3xl font-bold"><?php echo e($totalBranches); ?> <span class="text-base font-medium text-slate-500">Cabang</span></p>
            </div>
        </div>
        <div class="rounded-xl bg-white p-5 shadow-sm">
            <p class="text-sm text-slate-500">Total Kapasitas Kamar</p>
            <div class="mt-3 flex items-end justify-between">
                <p class="text-3xl font-bold"><?php echo e($totalRooms); ?> <span class="text-base font-medium text-slate-500">Kamar</span></p>
                <span class="rounded-md bg-blue-100 px-2 py-1 text-xs font-semibold text-blue-800"><?php echo e($occupancy); ?>% Terisi</span>
            </div>
        </div>
        <div class="rounded-xl bg-white p-5 shadow-sm">
            <p class="text-sm text-slate-500">Fasilitas Terdistribusi</p>
            <p class="mt-3 text-3xl font-bold"><?php echo e($facilityCount); ?> <span class="text-base font-medium text-slate-500">Relasi fasilitas</span></p>
        </div>
    </section>

    <section class="overflow-hidden rounded-xl bg-white shadow-sm">
        <div class="flex flex-col gap-3 border-b border-slate-100 p-4 md:flex-row md:items-center md:justify-between">
            <form method="GET" action="<?php echo e(route('owner.branches.index')); ?>" class="flex w-full max-w-xl gap-2">
                <input type="search" name="q" value="<?php echo e($search); ?>" placeholder="Cari nama cabang, kode cabang, atau alamat..." class="w-full rounded-lg border-0 bg-indigo-50 px-4 py-3 text-sm outline-none ring-blue-300 focus:ring-2">
                <button class="rounded-lg bg-blue-900 px-4 text-sm font-semibold text-white">Cari</button>
                <?php if($search !== ''): ?>
                    <a href="<?php echo e(route('owner.branches.index')); ?>" class="rounded-lg bg-slate-100 px-4 py-3 text-sm">Reset</a>
                <?php endif; ?>
            </form>
            <a href="<?php echo e(route('owner.branches.index')); ?>" title="Muat ulang" class="self-end rounded-lg p-2 text-slate-500 hover:bg-slate-100">↻</a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[850px] text-left text-sm">
                <thead class="bg-indigo-50 text-xs uppercase tracking-wide text-slate-600">
                    <tr>
                        <th class="px-6 py-4">Nama Cabang</th>
                        <th class="px-6 py-4">Alamat</th>
                        <th class="px-6 py-4">Kategori</th>
                        <th class="px-6 py-4 text-center">Kapasitas</th>
                        <th class="px-6 py-4">Fasilitas</th>
                        <th class="px-6 py-4">Lokasi</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_2 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-6 py-5">
                                <a href="<?php echo e(route('owner.branches.show', $branch)); ?>" class="font-semibold text-slate-900 hover:text-blue-800"><?php echo e($branch->name); ?></a>
                                <p class="mt-1 text-xs text-blue-800"><?php echo e($branch->branch_code); ?></p>
                            </td>
                            <td class="max-w-xs px-6 py-5 text-slate-500"><?php echo e(\Illuminate\Support\Str::limit($branch->address, 100)); ?></td>
                            <td class="px-6 py-5">
                                    <?php if($branch->gender_type): ?>
                                        <span
                                        class="rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-semibold capitalize text-indigo-800"><?php echo e($branch->gender_type); ?></span><?php else: ?><span
                                            class="text-xs text-amber-600">Belum diatur</span>
                                    <?php endif; ?>
                                </td>
                            <td class="px-6 py-5 text-center font-semibold"><?php echo e($branch->rooms_count); ?> kamar</td>
                            <td class="px-6 py-5">
                                <div class="flex max-w-sm flex-wrap gap-1.5">
                                    <?php $__empty_3 = true; $__currentLoopData = $branch->facilities->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                        <span class="rounded-md bg-indigo-50 px-2 py-1 text-xs text-slate-700"><?php echo e($facility->facility_name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                        <span class="text-xs text-slate-400">Belum ada fasilitas</span>
                                    <?php endif; ?>
                                    <?php if($branch->facilities->count() > 4): ?>
                                        <span class="rounded-md bg-slate-100 px-2 py-1 text-xs">+<?php echo e($branch->facilities->count() - 4); ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                             <td class="px-6 py-5">
                                    <?php if($branch->latitude !== null && $branch->longitude !== null): ?>
                                    <span class="text-xs font-medium text-emerald-700">Titik tersimpan</span><?php else: ?><span
                                            class="text-xs font-medium text-amber-600">Belum ditentukan</span>
                                    <?php endif; ?>
                            </td>
                            <td class="px-6 py-5">
                                <span class="rounded-full px-2.5 py-1 text-xs font-semibold <?php echo e($branch->status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'); ?>">
                                    <?php echo e($branch->status === 'active' ? 'Aktif' : 'Nonaktif'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-5">
                                <div class="flex justify-end gap-3">
                                    <a href="<?php echo e(route('owner.branches.show', $branch)); ?>" class="font-semibold text-blue-800 hover:underline">Detail</a>
                                    <a href="<?php echo e(route('owner.branches.edit', $branch)); ?>" class="font-semibold text-slate-700 hover:underline">Edit</a>
                                    <form method="POST" action="<?php echo e(route('owner.branches.destroy', $branch)); ?>" onsubmit="return confirm('Yakin ingin menghapus cabang ini?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="font-semibold text-red-600 hover:underline">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <tr><td colspan="6" class="px-6 py-16 text-center text-slate-500">Belum ada data cabang kos yang cocok.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="flex flex-col gap-3 border-t border-slate-100 bg-slate-50 px-6 py-4 text-sm text-slate-500 md:flex-row md:items-center md:justify-between">
            <p>Menampilkan <?php echo e($branches->firstItem() ?? 0); ?>–<?php echo e($branches->lastItem() ?? 0); ?> dari <?php echo e($branches->total()); ?> cabang kos</p>
            <?php echo e($branches->links()); ?>

        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.owner.container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\nesaKost2\resources\views\pages\owner\branches\index.blade.php ENDPATH**/ ?>