<?php $__env->startSection('title', 'Perpanjangan Sewa'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-slate-50 px-6 py-10">
    <div class="mx-auto max-w-3xl">
        <a href="<?php echo e(route('tenant.dashboard')); ?>" class="text-sm font-medium text-blue-900 hover:underline">&larr; Kembali ke dashboard</a>

        <div class="mt-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:p-8">
            <p class="text-sm font-semibold text-blue-900">Perpanjangan masa sewa</p>
            <h1 class="mt-2 text-2xl font-bold text-slate-900">Perpanjang kamar kamu</h1>
            <p class="mt-2 text-sm text-slate-600">Kamu dapat melanjutkan masa sewa kamar yang sama tanpa mengajukan booking baru.</p>

            <div class="mt-6 grid gap-4 rounded-xl bg-slate-50 p-5 sm:grid-cols-2">
                <div><p class="text-xs text-slate-500">Kost</p><p class="mt-1 font-semibold text-slate-900"><?php echo e($rent->room?->branchDorm?->name ?? '-'); ?></p></div>
                <div><p class="text-xs text-slate-500">Kamar</p><p class="mt-1 font-semibold text-slate-900"><?php echo e($rent->room?->room_code ?? '-'); ?></p></div>
                <div><p class="text-xs text-slate-500">Masa sewa saat ini berakhir</p><p class="mt-1 font-semibold text-slate-900"><?php echo e($rent->end_date->format('d M Y')); ?></p></div>
                <div><p class="text-xs text-slate-500">Mulai perpanjangan</p><p class="mt-1 font-semibold text-slate-900"><?php echo e($rent->end_date->copy()->addDay()->format('d M Y')); ?></p></div>
                <div><p class="text-xs text-slate-500">Harga per bulan saat ini</p><p class="mt-1 font-semibold text-slate-900">Rp<?php echo e(number_format((float) $rent->room->monthly_price, 0, ',', '.')); ?></p></div>
            </div>

            <?php if($existingRenewal): ?>
                <div class="mt-6 rounded-xl border border-amber-200 bg-amber-50 p-5">
                    <p class="font-semibold text-amber-900">Pengajuan perpanjangan sudah ada</p>
                    <p class="mt-1 text-sm text-amber-800">Booking <?php echo e($existingRenewal->booking_code); ?> berstatus <?php echo e($existingRenewal->status === 'confirmed' ? 'dikonfirmasi' : 'menunggu pembayaran'); ?>.</p>
                    <a href="<?php echo e(route('tenant.bookings.show', $existingRenewal->id)); ?>" class="mt-3 inline-flex text-sm font-semibold text-blue-900 underline">Lihat pengajuan</a>
                </div>
            <?php elseif(!$eligibility['eligible']): ?>
                <div class="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <p class="font-semibold text-slate-900">Belum dapat mengajukan perpanjangan</p>
                    <p class="mt-1 text-sm text-slate-600"><?php echo e($eligibility['message']); ?></p>
                </div>
            <?php else: ?>
                <div class="mt-6 rounded-xl border border-blue-100 bg-blue-50 p-5">
                    <p class="font-semibold text-blue-950">Periode pengajuan tersedia</p>
                    <p class="mt-1 text-sm text-blue-900">Pengajuan dibuka sampai <?php echo e($eligibility['closes_at']->format('d M Y')); ?>. Setelah pengajuan dibuat, kamu memiliki waktu 72 jam untuk menyelesaikan pembayaran.</p>
                </div>

                <form method="POST" action="<?php echo e(route('tenant.rents.renewal.store', $rent->id)); ?>" class="mt-6 space-y-5">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="duration_month" class="mb-2 block text-sm font-semibold text-slate-800">Durasi perpanjangan</label>
                        <select id="duration_month" name="duration_month" required class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-blue-900 focus:outline-none focus:ring-1 focus:ring-blue-900">
                            <option value="1" <?php if(old('duration_month') == 1): echo 'selected'; endif; ?>>1 bulan</option>
                            <option value="3" <?php if(old('duration_month', 3) == 3): echo 'selected'; endif; ?>>3 bulan</option>
                            <option value="6" <?php if(old('duration_month') == 6): echo 'selected'; endif; ?>>6 bulan</option>
                        </select>
                        <?php $__errorArgs = ['duration_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="rounded-lg border border-slate-200 p-4 text-sm text-slate-600">
                        <p class="font-semibold text-slate-800">Perlu diperhatikan</p>
                        <ul class="mt-2 list-disc space-y-1 pl-5">
                            <li>Perpanjangan berlaku untuk kamar yang sama.</li>
                            <li>Pembayaran dilakukan penuh di awal periode.</li>
                            <li>Kamar ditahan selama 72 jam sejak pengajuan.</li>
                            <li>Jika pembayaran tidak selesai dalam 72 jam, pengajuan otomatis kedaluwarsa.</li>
                        </ul>
                    </div>
                    <button type="submit" class="w-full rounded-lg bg-blue-900 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-950">Ajukan Perpanjangan</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.tenant.container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\nesaKost2\resources\views\pages\tenant\renewals\create.blade.php ENDPATH**/ ?>