

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('main'); ?>
    <?php
        $money = fn($value) => 'Rp ' . number_format((float) $value, 0, ',', '.');
        $branchColors = ['#2450D8', '#12A5E5', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444', '#64748B'];
        $maxMethodCount = max(1, (int) ($paymentMethodTotals->max('transaction_count') ?? 1));
    ?>

    <div class="space-y-6">
        <section class="rounded-xl border border-slate-100 bg-white px-5 py-5 sm:px-6">
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Dashboard</h1>
            <p class="mt-1 text-sm text-slate-500">Ringkasan operasional pengelolaan kos.</p>
        </section>



        <section class="flex flex-col gap-3 rounded-xl border border-slate-100 bg-white p-3 sm:flex-row sm:items-center">
            <div class="flex flex-wrap gap-2">

                
                <a href="<?php echo e(route('owner.dashboard')); ?>"
                    class="rounded-lg px-3 py-2 text-xs font-semibold transition
            <?php echo e($selectedBranchId === null ? 'bg-[#1D4E80] text-white' : 'bg-[#F0F3FF] text-slate-600 hover:bg-blue-100'); ?>">
                    Semua Cabang
                </a>

                
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('owner.dashboard', ['branch_id' => $branch->id])); ?>"
                        class="rounded-lg px-3 py-2 text-xs font-medium transition
                <?php echo e($selectedBranchId === (string) $branch->id
                    ? 'bg-[#1D4E80] text-white font-semibold'
                    : 'bg-[#F0F3FF] text-slate-600 hover:bg-blue-100'); ?>">
                        <?php echo e($branch->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </section>



        <section class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
            <?php
                $statCards = [
                    [
                        'label' => 'Total Cabang Kos',
                        'value' => $stats['branches'],
                        'entity' => 'cabang',
                        'icon' => 'grid',
                    ],
                    [
                        'label' => 'Total Kamar',
                        'value' => $stats['rooms'],
                        'entity' => 'kamar',
                        'icon' => 'columns',
                    ],
                    [
                        'label' => 'Total Penyewa',
                        'value' => $stats['tenants'],
                        'entity' => 'penyewa',
                        'icon' => 'user-check',
                    ],
                ];
            ?>
            <?php $__currentLoopData = $statCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="rounded-xl border border-slate-100 bg-white p-5">
                    <div class="flex items-start justify-between gap-3">
                        <p class="text-sm font-medium text-slate-500"><?php echo e($card['label']); ?></p>
                        <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-[#315F96]">
                            <i data-feather="<?php echo e($card['icon']); ?>" class="h-5 w-5"></i>
                        </span>
                    </div>
                    <div class="mt-2 flex items-baseline gap-2">
                        <span
                            class="text-3xl font-bold tracking-tight text-slate-900"><?php echo e(number_format($card['value'])); ?></span>
                        <span class="text-xs font-medium text-slate-500"><?php echo e($card['entity']); ?></span>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <section class="rounded-xl border border-slate-100 bg-white p-5 sm:p-6">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                    <h2 class="flex items-center gap-2 text-base font-semibold text-slate-800">Okupansi Kamar per Cabang
                    </h2>
                    <p class="mt-1 max-w-2xl text-xs leading-5 text-slate-500">Dihitung dari jumlah kamar dan data sewa
                        aktif yang tanggal sewanya mencakup hari ini.</p>
                </div>
                <div class="flex flex-wrap gap-3 text-xs text-slate-500">
                    <span class="flex items-center gap-1.5"><span class="h-2 w-2 rounded-full bg-blue-700"></span>Kamar
                        Terisi</span>
                    <span class="flex items-center gap-1.5"><span class="h-2 w-2 rounded-full bg-sky-500"></span>Kamar
                        Kosong</span>
                </div>
            </div>

            <?php if($branchOccupancy->isEmpty()): ?>
                <div class="mt-4 rounded-lg bg-[#F0F3FF] px-4 py-12 text-center text-sm text-slate-500">Belum ada data
                    cabang atau kamar untuk ditampilkan.</div>
            <?php else: ?>
                <div class="mt-4 rounded-lg bg-[#F0F3FF] p-4 sm:p-5">
                    <div class="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3" id="occupancy-chart-grid">
                        <?php $__currentLoopData = $branchOccupancy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="occupancy-card min-w-0 rounded-lg" data-branch="<?php echo e($branch['id']); ?>">
                                <div class="mx-auto h-40 w-40 sm:h-44 sm:w-44">
                                    <canvas id="occupancy-chart-<?php echo e($branch['id']); ?>"
                                        aria-label="Grafik okupansi <?php echo e($branch['name']); ?>"></canvas>
                                </div>
                                <p class="mt-3 text-center text-xs font-semibold text-slate-600"><?php echo e($branch['name']); ?></p>
                                <div class="mt-3 rounded-lg border border-slate-100 bg-white p-3">
                                    <p class="flex items-center gap-2 text-xs text-slate-500">
                                        <span class="h-2 w-2 rounded-full"
                                            style="background-color: <?php echo e($branchColors[$index % count($branchColors)]); ?>"></span>
                                        <?php echo e($branch['name']); ?>

                                    </p>
                                    <p class="mt-1 text-xl font-bold text-slate-800"><?php echo e($branch['percentage']); ?>%</p>
                                    <p class="text-[11px] text-slate-500"><?php echo e($branch['occupied']); ?> terisi /
                                        <?php echo e($branch['total']); ?> kamar · <?php echo e($branch['vacant']); ?> kosong</p>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>

        <section class="grid grid-cols-1 gap-5 xl:grid-cols-2">
            <article class="rounded-xl border border-slate-100 bg-white p-5 sm:p-6">
                <h2 class="flex items-center gap-2 text-base font-semibold text-slate-800">Ringkasan Data Sewa</h2>

                <div class="mt-5 grid grid-cols-3 gap-2">
                    <div class="rounded-lg bg-[#F0F3FF] p-3">
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Total Kontrak</p>
                        <p class="mt-1 text-xl font-bold text-slate-800"><?php echo e(number_format($totalRents)); ?></p>
                        <p class="mt-1 text-[11px] text-slate-500">Kontrak tercatat</p>
                    </div>
                    <div class="rounded-lg bg-emerald-50 p-3">
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-emerald-800">Berjalan</p>
                        <p class="mt-1 text-xl font-bold text-emerald-800"><?php echo e(number_format($activeRents)); ?></p>
                        <p class="mt-1 text-[11px] text-emerald-800">Status active</p>
                    </div>
                    <div class="rounded-lg bg-slate-100 p-3">
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Selesai</p>
                        <p class="mt-1 text-xl font-bold text-slate-700"><?php echo e(number_format($finishedRents)); ?></p>
                        <p class="mt-1 text-[11px] text-slate-500">Kontrak selesai</p>
                    </div>
                </div>

                <div class="mt-5">
                    <div class="flex items-center justify-between gap-3 text-xs">
                        <span class="font-medium text-slate-600">Rasio Okupansi Kamar (<?php echo e($occupiedRooms); ?> /
                            <?php echo e($roomCount); ?>)</span>
                        <span
                            class="font-semibold text-slate-700"><?php echo e($roomCount > 0 ? round(($occupiedRooms / $roomCount) * 100) : 0); ?>%
                            Terisi</span>
                    </div>
                    <div class="mt-2 h-2 overflow-hidden rounded-full bg-blue-100">
                        <div class="h-full rounded-full bg-[#1D4E80]"
                            style="width: <?php echo e($roomCount > 0 ? min(100, round(($occupiedRooms / $roomCount) * 100)) : 0); ?>%">
                        </div>
                    </div>
                </div>
                <a href="<?php echo e(url('/owner/sewa')); ?>"
                    class="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-blue-50 px-4 py-3 text-xs font-semibold text-[#315F96] transition hover:bg-blue-100">
                    Kelola Data Sewa <i data-feather="arrow-right" class="h-4 w-4"></i>
                </a>
            </article>

            <article class="rounded-xl border border-slate-100 bg-white p-5 sm:p-6">
                <h2 class="flex items-center gap-2 text-base font-semibold text-slate-800">Ringkasan Pembayaran</h2>
                <p class="mt-1 text-xs text-slate-500">Akumulasi pembayaran dengan tanggal pembayaran terisi.</p>
                <div class="mt-5 rounded-lg bg-[#F0F3FF] p-4">
                    <p class="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Total Pembayaran Tercatat
                    </p>
                    <p class="mt-1 text-2xl font-extrabold tracking-tight text-[#1D4E80] sm:text-3xl">
                        <?php echo e($money($totalPaidAmount)); ?></p>
                    <div class="mt-2 flex items-center justify-between gap-3 text-xs text-slate-500">
                        <span>Total pembayaran terverifikasi</span>
                        <strong class="text-slate-700"><?php echo e(number_format($paidTransactions)); ?> transaksi</strong>
                    </div>
                </div>
                <div class="mt-3 space-y-2">
                    <?php $__empty_2 = true; $__currentLoopData = $paymentMethodTotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="flex items-center gap-3 rounded-lg bg-[#F0F3FF] px-3 py-3 text-xs">
                            <i data-feather="credit-card" class="h-4 w-4 shrink-0 text-slate-500"></i>
                            <span
                                class="flex-1 text-slate-600"><?php echo e($method->payment_method ?: 'Metode tidak dicatat'); ?></span>
                            <div class="h-1.5 w-14 overflow-hidden rounded-full bg-blue-100">
                                <div class="h-full bg-[#1D4E80]"
                                    style="width: <?php echo e(min(100, round(($method->transaction_count / $maxMethodCount) * 100))); ?>%">
                                </div>
                            </div>
                            <strong
                                class="w-10 text-right text-slate-700"><?php echo e(number_format($method->transaction_count)); ?></strong>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <p class="rounded-lg bg-[#F0F3FF] px-3 py-4 text-xs text-slate-500">Belum ada pembayaran
                            terverifikasi.</p>
                    <?php endif; ?>
                </div>
                <a href="<?php echo e(url('/owner/pembayaran')); ?>"
                    class="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-[#1D4E80] px-4 py-3 text-xs font-semibold text-white transition hover:bg-[#173e66]">
                    Kelola Data Pembayaran <i data-feather="arrow-right" class="h-4 w-4"></i>
                </a>
            </article>
        </section>

        <section class="rounded-xl border border-slate-100 bg-white p-5 sm:p-6">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                    <h2 class="flex items-center gap-2 text-base font-semibold text-slate-800">Pendapatan Bulanan per Cabang
                    </h2>
                </div>
                <span class="rounded-md bg-blue-50 px-3 py-1.5 text-xs font-semibold text-[#315F96]">Tahun
                    <?php echo e($year); ?></span>
            </div>
            <div class="mt-4 rounded-lg bg-[#F0F3FF] p-3 sm:p-5">
                <div class="h-[280px] sm:h-[320px]">
                    <canvas id="monthlyRevenueChart"
                        aria-label="Grafik pendapatan bulanan per cabang untuk tahun <?php echo e($year); ?>"></canvas>
                </div>
            </div>
        </section>

        <section class="overflow-hidden rounded-xl border border-slate-100 bg-white">
            <div class="flex flex-col gap-3 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                <div>
                    <h2 class="text-base font-semibold text-slate-800">Pembayaran Terbaru</h2>
                    <p class="mt-1 text-xs text-slate-500">Lima pembayaran terbaru yang telah memiliki tanggal pembayaran.
                    </p>
                </div>
                <a href="<?php echo e(url('/owner/pembayaran')); ?>"
                    class="inline-flex items-center justify-center gap-2 self-start rounded-lg bg-blue-50 px-3 py-2 text-xs font-semibold text-[#315F96] transition hover:bg-blue-100 sm:self-auto">
                    Lihat Semua Pembayaran <i data-feather="arrow-right" class="h-4 w-4"></i>
                </a>
            </div>
            <div class="overflow-x-auto">
                <table id="recent-payments-table" class="min-w-[850px] w-full border-collapse text-left">
                    <thead class="bg-[#F0F3FF] text-[10px] uppercase tracking-wide text-slate-600">
                        <tr>
                            <th class="px-5 py-4 font-bold">Tanggal Pembayaran</th>
                            <th class="px-5 py-4 font-bold">Kode Pembayaran</th>
                            <th class="px-5 py-4 font-bold">Kode Booking</th>
                            <th class="px-5 py-4 font-bold">Penyewa</th>
                            <th class="px-5 py-4 font-bold">Metode Pembayaran</th>
                            <th class="px-5 py-4 text-right font-bold">Total Pembayaran</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-xs text-slate-600">
                        <?php $__empty_2 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <?php
                                $tenantName =
                                    trim(($payment->fname ?? '') . ' ' . ($payment->lname ?? '')) ?: 'Penyewa';
                                $paidDate = $payment->paid_at
                                    ? \Carbon\Carbon::parse($payment->paid_at)->format('d M Y')
                                    : '-';
                            ?>
                            <tr class="payment-row hover:bg-slate-50"
                                data-search="<?php echo e(strtolower(($payment->payment_code ?? '') . ' ' . ($payment->booking_code ?? '') . ' ' . $tenantName . ' ' . ($payment->payment_method ?? ''))); ?>">
                                <td class="whitespace-nowrap px-5 py-4"><?php echo e($paidDate); ?></td>
                                <td class="whitespace-nowrap px-5 py-4 font-semibold text-[#315F96]">
                                    <?php echo e($payment->payment_code); ?></td>
                                <td class="whitespace-nowrap px-5 py-4"><?php echo e($payment->booking_code); ?></td>
                                <td class="whitespace-nowrap px-5 py-4 font-medium text-slate-800"><?php echo e($tenantName); ?>

                                </td>
                                <td class="whitespace-nowrap px-5 py-4"><?php echo e($payment->payment_method ?: '-'); ?></td>
                                <td class="whitespace-nowrap px-5 py-4 text-right font-semibold text-slate-800">
                                    <?php echo e($money($payment->amount)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <tr>
                                <td colspan="6" class="px-5 py-8 text-center text-sm text-slate-500">Belum ada
                                    pembayaran terverifikasi.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <p id="payments-empty" class="hidden px-5 py-8 text-center text-sm text-slate-500">Tidak ada transaksi
                    yang cocok dengan pencarian.</p>
            </div>
        </section>

        <p class="text-center text-[11px] text-slate-400">&copy; 2026 nesaKost. All rights reserved.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            if (window.feather) feather.replace();

            const branchOccupancy = <?php echo json_encode($branchOccupancy, 15, 512) ?>;
            const branchColors = <?php echo json_encode($branchColors, 15, 512) ?>;
            const monthLabels = <?php echo json_encode($monthLabels, 15, 512) ?>;
            const revenueDatasets = <?php echo json_encode($monthlyRevenueDatasets, 15, 512) ?>;

            if (typeof Chart !== 'undefined') {
                branchOccupancy.forEach(function(branch, index) {
                    const canvas = document.getElementById('occupancy-chart-' + branch.id);
                    if (!canvas) return;

                    new Chart(canvas, {
                        type: 'pie',
                        data: {
                            labels: ['Kamar Terisi', 'Kamar Kosong'],
                            datasets: [{
                                data: [branch.occupied, branch.vacant],
                                backgroundColor: ['#2450D8', '#12A5E5'],
                                hoverOffset: 5,
                                borderWidth: 0
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    display: false
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            return context.label + ': ' + context.raw +
                                                ' kamar';
                                        }
                                    }
                                }
                            }
                        }
                    });
                });

                const revenueCanvas = document.getElementById('monthlyRevenueChart');
                if (revenueCanvas) {
                    const chartDatasets = revenueDatasets.map(function(dataset, index) {
                        return {
                            label: dataset.label,
                            data: dataset.data,
                            backgroundColor: branchColors[index % branchColors.length],
                            borderRadius: 4,
                            maxBarThickness: 18
                        };
                    });

                    new Chart(revenueCanvas, {
                        type: 'bar',
                        data: {
                            labels: monthLabels,
                            datasets: chartDatasets
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            interaction: {
                                mode: 'index',
                                intersect: false
                            },
                            plugins: {
                                legend: {
                                    position: 'bottom',
                                    labels: {
                                        usePointStyle: true,
                                        boxWidth: 7,
                                        font: {
                                            size: 11
                                        }
                                    }
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            return context.dataset.label + ': ' + new Intl.NumberFormat(
                                                'id-ID', {
                                                    style: 'currency',
                                                    currency: 'IDR',
                                                    maximumFractionDigits: 0
                                                }).format(context.raw);
                                        }
                                    }
                                }
                            },
                            scales: {
                                x: {
                                    grid: {
                                        display: false
                                    },
                                    ticks: {
                                        color: '#64748b',
                                        font: {
                                            size: 10
                                        }
                                    },
                                    border: {
                                        display: false
                                    }
                                },
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        color: '#64748b',
                                        font: {
                                            size: 10
                                        },
                                        callback: function(value) {
                                            return new Intl.NumberFormat('id-ID', {
                                                notation: 'compact',
                                                style: 'currency',
                                                currency: 'IDR',
                                                maximumFractionDigits: 1
                                            }).format(value);
                                        }
                                    },
                                    grid: {
                                        color: '#dfe6f5'
                                    },
                                    border: {
                                        display: false
                                    }
                                }
                            }
                        }
                    });
                }
            }

            // Pencarian pembayaran terbaru.
            const searchInput = document.getElementById('dashboard-search');
            const paymentRows = document.querySelectorAll('.payment-row');
            const emptyMessage = document.getElementById('payments-empty');

            searchInput?.addEventListener('input', function() {
                const query = searchInput.value.trim().toLowerCase();
                let visibleRows = 0;
                paymentRows.forEach(function(row) {
                    const text = (row.dataset.search || row.textContent).toLowerCase();
                    const matches = text.includes(query);
                    row.classList.toggle('hidden', !matches);
                    if (matches) visibleRows++;
                });
                emptyMessage?.classList.toggle('hidden', visibleRows !== 0);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('components.layouts.owner.container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\nesaKost2\resources\views\pages\owner\dashboard\index.blade.php ENDPATH**/ ?>