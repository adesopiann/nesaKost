<?php $__env->startSection('main'); ?>

<div class="space-y-6 text-slate-800">
    <?php echo $__env->make('pages.owner.branches.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="rounded-xl bg-white p-6 shadow-sm">
        <p class="text-sm text-slate-500"><a href="<?php echo e(route('owner.branches.index')); ?>" class="hover:text-blue-800">Data Cabang Kos</a> / <span class="font-semibold text-blue-800">Detail Cabang Kos</span></p>
        <div class="mt-3 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
                <h1 class="text-3xl font-bold"><?php echo e($branch->name); ?></h1>
                <div class="mt-3 flex flex-wrap items-center gap-2 text-sm text-slate-500">
                    <span class="font-semibold text-blue-800"><?php echo e($branch->branch_code); ?></span>
                    <span>•</span>
                    <span>Dibuat <?php echo e($branch->created_at?->format('d M Y') ?? '—'); ?></span>
                    <span>•</span>
                    <span class="rounded-full px-2.5 py-1 text-xs font-semibold <?php echo e($branch->status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'); ?>"><?php echo e($branch->status === 'active' ? 'Aktif Beroperasi' : 'Nonaktif'); ?></span>
                </div>
            </div>
            <a href="<?php echo e(route('owner.branches.edit', $branch)); ?>" class="rounded-lg bg-blue-900 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-800">Edit Cabang</a>
        </div>
    </section>

    <section class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div class="rounded-xl bg-white p-5 shadow-sm"><p class="text-sm text-slate-500">Kapasitas Kamar</p><p class="mt-2 text-2xl font-bold"><?php echo e($totalRooms); ?> <span class="text-sm font-medium text-slate-500">kamar</span></p></div>
        <div class="rounded-xl bg-white p-5 shadow-sm"><p class="text-sm text-slate-500">Kamar Terisi</p><p class="mt-2 text-2xl font-bold"><?php echo e($occupiedRooms); ?></p></div>
        <div class="rounded-xl bg-white p-5 shadow-sm"><p class="text-sm text-slate-500">Kamar Tersedia</p><p class="mt-2 text-2xl font-bold"><?php echo e($availableRooms); ?></p></div>
        <div class="rounded-xl bg-white p-5 shadow-sm"><p class="text-sm text-slate-500">Tingkat Okupansi</p><p class="mt-2 text-2xl font-bold"><?php echo e($totalRooms ? round($occupiedRooms / $totalRooms * 100) : 0); ?>%</p></div>
    </section>

    <section class="grid gap-6 lg:grid-cols-3">
        <div class="space-y-6 rounded-xl bg-white p-6 shadow-sm lg:col-span-2">
            <h2 class="text-lg font-bold">Informasi Cabang</h2>
            <div>
                <p class="text-sm font-semibold text-slate-500">Alamat lengkap</p>
                <p class="mt-2 leading-relaxed"><?php echo e($branch->address); ?></p>
            </div>
            <div>
                    <p class="text-sm font-semibold text-slate-500">Kategori kost</p>
                    <p class="mt-2 font-medium capitalize"><?php echo e($branch->gender_type ?: 'Belum ditentukan'); ?></p>
            </div>
             <div>
                    <p class="text-sm font-semibold text-slate-500">Koordinat lokasi</p>
                    <?php if($branch->latitude !== null && $branch->longitude !== null): ?>
                        <p class="mt-2 text-sm"><?php echo e($branch->latitude); ?>, <?php echo e($branch->longitude); ?></p>
                        <a class="mt-2 inline-flex text-sm font-semibold text-blue-800 hover:underline"
                            href="https://www.openstreetmap.org/?mlat=<?php echo e($branch->latitude); ?>&mlon=<?php echo e($branch->longitude); ?>#map=18/<?php echo e($branch->latitude); ?>/<?php echo e($branch->longitude); ?>"
                            target="_blank" rel="noopener noreferrer">Lihat titik di OpenStreetMap ↗</a>
                    <?php else: ?>
                        <p class="mt-2 text-sm text-amber-600">Lokasi belum ditentukan. Lengkapi melalui menu Edit Cabang.
                        </p>
                    <?php endif; ?>
            </div>
            <div>
                <p class="text-sm font-semibold text-slate-500">Pemilik properti</p>
                <p class="mt-2 font-medium"><?php echo e($branch->owner?->user ? trim($branch->owner->user->fname . ' ' . $branch->owner->user->lname) : 'Pemilik tidak ditemukan'); ?></p>
                <?php if($branch->owner?->user): ?>
                    <p class="mt-1 text-sm text-slate-500"><?php echo e($branch->owner->user->email); ?></p>
                <?php endif; ?>
            </div>
            <div>
                <p class="text-sm font-semibold text-slate-500">Fasilitas umum</p>
                <div class="mt-3 flex flex-wrap gap-2">
                    <?php $__empty_2 = true; $__currentLoopData = $branch->facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <span class="rounded-lg bg-indigo-50 px-3 py-2 text-sm"><?php echo e($facility->facility_name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <p class="text-sm text-slate-400">Belum ada fasilitas yang terhubung ke cabang ini.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <aside class="rounded-xl bg-white p-6 shadow-sm">
            <h2 class="text-lg font-bold">Ringkasan</h2>
            <dl class="mt-4 space-y-4 text-sm">
                <div><dt class="text-slate-500">Kode cabang</dt><dd class="mt-1 font-semibold"><?php echo e($branch->branch_code); ?></dd></div>
                <div><dt class="text-slate-500">Status</dt><dd class="mt-1 font-semibold"><?php echo e($branch->status === 'active' ? 'Aktif' : 'Nonaktif'); ?></dd></div>
                <div><dt class="text-slate-500">Terakhir diperbarui</dt><dd class="mt-1 font-semibold"><?php echo e($branch->updated_at?->format('d M Y, H:i') ?? '—'); ?></dd></div>
            </dl>
            <a href="<?php echo e(route('owner.branches.index')); ?>" class="mt-6 inline-flex w-full justify-center rounded-lg bg-slate-100 px-4 py-3 text-sm font-semibold hover:bg-slate-200">Kembali ke daftar</a>
        </aside>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.owner.container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\nesaKost2\resources\views\pages\owner\branches\show.blade.php ENDPATH**/ ?>