<?php $__env->startSection('title', 'nesaKost - Temukan Kost Dekat UNESA'); ?>

<?php $__env->startSection('content'); ?>

<section id="cari" class="bg-gradient-to-b from-slate-50 to-white">
    <div class="mx-auto max-w-7xl px-6 py-12 md:py-16 lg:py-20">
        <?php if(auth()->guard()->guest()): ?>
            <div class="grid items-center gap-12 lg:grid-cols-2">
                <div>
                    <span class="mb-5 inline-flex items-center gap-2 rounded-full bg-blue-50 px-3 py-2 text-xs font-semibold uppercase tracking-wider text-blue-900">
                        Kost di sekitar UNESA
                    </span>

                    <h1 class="max-w-xl text-4xl font-semibold leading-tight tracking-tight text-slate-900 md:text-5xl lg:text-6xl">
                        Temukan tempat tinggal yang <span class="text-blue-900">pas untukmu.</span>
                    </h1>

                    <p class="mt-6 max-w-lg text-sm leading-7 text-slate-500 md:text-base">
                        Cari kost berdasarkan kampus tujuan dan tipe hunian. Mulai pencarianmu dengan informasi yang ringkas, jelas, dan mudah dibandingkan.
                    </p>

                    <div class="mt-5 flex items-center gap-2 text-xs text-slate-500">
                        <span class="text-green-600">✓</span>
                        Pencarian berdasarkan radius maksimal 5 km dari kampus pilihan.
                    </div>
                </div>
        <?php else: ?>
            <?php if(auth()->user()->role === 'tenant'): ?>
                <div class="mb-8">
                    <span class="text-xs font-semibold uppercase tracking-widest text-blue-900">Katalog nesaKost</span>
                    <h1 class="mt-3 text-3xl font-semibold tracking-tight text-slate-900 md:text-4xl">
                        Temukan Kost Impianmu.
                    </h1>
                    <p class="mt-3 max-w-2xl text-sm leading-7 text-slate-500 md:text-base">
                        Halo, <?php echo e(auth()->user()->fname ?? 'Tenant'); ?>! Temukan tempat tinggal yang sesuai dengan kebutuhanmu di sekitar kampus UNESA.
                    </p>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        
        <div class="mx-auto w-full max-w-3xl rounded-2xl border border-slate-100 bg-white p-6 shadow-xl shadow-slate-200/60 md:p-8">
            <h2 class="text-xl font-semibold text-slate-900">Mulai cari kost</h2>
            <p class="mt-1 text-sm text-slate-500">Pilih kampus sebagai titik referensi pencarian.</p>

            
            <form action="<?php echo e(url()->current()); ?>#properti" method="GET" class="mt-7 space-y-6">
                <fieldset>
                    <legend class="mb-3 block text-sm font-medium text-slate-700">Kampus tujuan</legend>
                    <div class="grid grid-cols-2 gap-3">
                        <?php $__currentLoopData = [
                            'kampus_1' => ['UNESA Kampus 1', 'Ketintang'],
                            'kampus_2' => ['UNESA Kampus 2', 'Lidah Wetan'],
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $campusOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="cursor-pointer">
                                <input type="radio" name="campus" value="<?php echo e($value); ?>" class="peer sr-only"
                                    <?php echo e(($campusKey ?? '') === $value ? 'checked' : ''); ?>>
                                <span class="block rounded-xl border border-slate-200 p-4 transition peer-checked:border-blue-900 peer-checked:bg-blue-50">
                                    <span class="mb-3 flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-blue-900">⌖</span>
                                    <span class="block text-sm font-semibold text-slate-800"><?php echo e($campusOption[0]); ?></span>
                                    <span class="mt-1 block text-xs text-slate-500"><?php echo e($campusOption[1]); ?></span>
                                </span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </fieldset>

                <fieldset>
                    <legend class="mb-3 block text-sm font-medium text-slate-700">Tipe kost (opsional)</legend>
                    <div class="grid grid-cols-3 gap-2">
                        <?php $__currentLoopData = ['putra' => 'Putra', 'putri' => 'Putri', 'campuran' => 'Campuran']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="cursor-pointer">
                                <input type="radio" name="gender" value="<?php echo e($value); ?>" class="peer sr-only"
                                    <?php echo e(($selectedGender ?? '') === $value ? 'checked' : ''); ?>>
                                <span class="block rounded-lg border border-slate-200 px-2 py-3 text-center text-xs font-medium text-slate-600 transition peer-checked:border-blue-900 peer-checked:bg-blue-50 peer-checked:text-blue-900">
                                    <?php echo e($label); ?>

                                </span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <label class="mt-3 flex cursor-pointer items-center gap-2 text-xs text-slate-500">
                        <input type="radio" name="gender" value="" class="accent-blue-900"
                            <?php echo e(($selectedGender ?? '') === '' ? 'checked' : ''); ?>>
                        Semua kategori
                    </label>
                </fieldset>

                <button type="submit" class="w-full rounded-lg bg-blue-900 px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-blue-800">
                    Cari kost di sekitar kampus →
                </button>
            </form>
        </div>

        <?php if(auth()->guard()->guest()): ?>
            </div>
        <?php endif; ?>
    </div>
</section>


<section id="properti" class="bg-slate-50 py-16 md:py-20">
    <div class="mx-auto max-w-7xl px-6">
        <div class="mb-10 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
                <span class="text-xs font-semibold uppercase tracking-widest text-blue-900">Pilihan kost</span>
                <h2 class="mt-3 text-3xl font-semibold tracking-tight text-slate-900">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->role === 'tenant'): ?>
                            Kost di Sekitar Kampus UNESA
                        <?php else: ?>
                            Informasi penting, mudah dibandingkan.
                        <?php endif; ?>
                    <?php else: ?>
                        Informasi penting, mudah dibandingkan.
                    <?php endif; ?>
                </h2>
                <p class="mt-3 max-w-xl text-sm leading-7 text-slate-500">
                    Temukan properti kost di sekitar kampus UNESA dengan informasi harga, jarak, tipe, dan ketersediaan.
                </p>
            </div>
            <div class="text-sm text-slate-500"><?php echo e($properties->total()); ?> properti ditemukan</div>
        </div>

        <?php if(!$hasCoordinates): ?>
            <div class="rounded-xl border border-amber-200 bg-amber-50 p-6 text-sm text-amber-800">
                Koordinat kampus belum dikonfigurasi. Lengkapi koordinat UNESA pada file .env untuk mengaktifkan pencarian.
            </div>
        <?php elseif($properties->isEmpty()): ?>
            <div class="rounded-xl border border-slate-200 bg-white p-12 text-center">
                <div class="text-4xl">⌕</div>
                <h3 class="mt-4 font-semibold text-slate-800">Belum ada kost yang ditemukan</h3>
                <p class="mt-2 text-sm text-slate-500">Coba pilih kategori lain atau kampus tujuan yang berbeda.</p>
            </div>
        <?php else: ?>
            <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal5d2054ee5fae8b14a45fd2c99a2eee30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d2054ee5fae8b14a45fd2c99a2eee30 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.guest.property-card','data' => ['property' => $property]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.guest.property-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['property' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($property)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d2054ee5fae8b14a45fd2c99a2eee30)): ?>
<?php $attributes = $__attributesOriginal5d2054ee5fae8b14a45fd2c99a2eee30; ?>
<?php unset($__attributesOriginal5d2054ee5fae8b14a45fd2c99a2eee30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d2054ee5fae8b14a45fd2c99a2eee30)): ?>
<?php $component = $__componentOriginal5d2054ee5fae8b14a45fd2c99a2eee30; ?>
<?php unset($__componentOriginal5d2054ee5fae8b14a45fd2c99a2eee30); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-10"><?php echo e($properties->links()); ?></div>
        <?php endif; ?>

        <p class="mt-6 text-xs text-slate-400">
            Jarak merupakan estimasi garis lurus dari titik kampus tujuan, bukan jarak perjalanan melalui jalan.
        </p>
    </div>
</section>


<?php if(auth()->guard()->guest()): ?>
    <section class="scroll-mt-24 bg-white py-20">
        <div class="mx-auto max-w-7xl px-6">
            <div class="max-w-xl">
                <span class="text-xs font-semibold uppercase tracking-widest text-blue-900">Untuk mahasiswa UNESA</span>
                <h2 class="mt-3 text-3xl font-semibold tracking-tight text-slate-900">Mencari kost tanpa berputar-putar.</h2>
            </div>

            <div class="mt-12 grid gap-10 md:grid-cols-3">
                <div>
                    <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-900">⌖</div>
                    <h3 class="mt-5 font-semibold text-slate-800">Mulai dari kampusmu</h3>
                    <p class="mt-3 text-sm leading-7 text-slate-500">Tentukan Kampus 1 atau Kampus 2 untuk melihat pilihan kost di sekitar lokasi kampus tujuan.</p>
                </div>
                <div>
                    <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-900">▦</div>
                    <h3 class="mt-5 font-semibold text-slate-800">Bandingkan dengan jelas</h3>
                    <p class="mt-3 text-sm leading-7 text-slate-500">Harga, jarak, kategori, dan ketersediaan kamar disajikan agar mudah dipahami.</p>
                </div>
                <div>
                    <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-900">✓</div>
                    <h3 class="mt-5 font-semibold text-slate-800">Informasi yang transparan</h3>
                    <p class="mt-3 text-sm leading-7 text-slate-500">Detail kost dapat diketahui sebelum kamu melanjutkan proses booking.</p>
                </div>
            </div>
        </div>
    </section>

    
    <section id="pemilik" class="bg-white pb-20">
        <div class="mx-auto max-w-7xl px-6">
            <div class="overflow-hidden rounded-2xl bg-blue-900 p-8 text-white md:p-14">
                <div class="grid items-center gap-10 md:grid-cols-2">
                    <div>
                        <span class="text-xs font-semibold uppercase tracking-widest text-blue-200">Untuk pemilik kost</span>
                        <h2 class="mt-4 text-3xl font-semibold leading-tight md:text-4xl">Kelola informasi kost dengan lebih teratur.</h2>
                        <p class="mt-5 max-w-lg text-sm leading-7 text-blue-100">
                            Kenalkan properti Anda kepada calon penghuni UNESA. Kelola informasi kamar, harga, dan ketersediaan melalui satu platform.
                        </p>
                        <?php if(\Illuminate\Support\Facades\Route::has('login')): ?>
                            <a href="<?php echo e(route('login')); ?>" class="mt-8 inline-flex rounded-lg bg-white px-5 py-3 text-sm font-semibold text-blue-900 transition hover:bg-blue-50">
                                Pelajari untuk pemilik kost →
                            </a>
                        <?php else: ?>
                            <span class="mt-8 inline-flex rounded-lg bg-white/15 px-5 py-3 text-sm text-white">Pendaftaran pemilik kost segera hadir</span>
                        <?php endif; ?>
                    </div>

                    <div class="rounded-xl border border-white/20 bg-white/10 p-6">
                        <p class="text-sm font-medium text-blue-100">Ringkasan pengelolaan properti</p>
                        <div class="mt-6 grid grid-cols-2 gap-4">
                            <div class="rounded-lg bg-white/10 p-4">
                                <p class="text-xs text-blue-200">Data properti</p>
                                <p class="mt-2 text-xl font-semibold">Teratur</p>
                            </div>
                            <div class="rounded-lg bg-white/10 p-4">
                                <p class="text-xs text-blue-200">Informasi kamar</p>
                                <p class="mt-2 text-xl font-semibold">Terpusat</p>
                            </div>
                        </div>
                        <div class="mt-4 rounded-lg bg-white/10 p-4">
                            <p class="text-xs text-blue-200">Kelola informasi kost dalam satu platform</p>
                            <div class="mt-4 h-2 rounded-full bg-white/20">
                                <div class="h-2 w-3/4 rounded-full bg-white"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.guest.container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\nesaKost2\resources\views\pages\guest\index.blade.php ENDPATH**/ ?>