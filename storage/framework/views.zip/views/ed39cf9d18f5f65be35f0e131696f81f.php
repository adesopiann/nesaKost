<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['property']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['property']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="group overflow-hidden rounded-xl border border-slate-200 bg-white transition duration-300 hover:-translate-y-1 hover:shadow-lg">
    <a href="<?php echo e(route('guest.properties.show', $property->id)); ?>">
        <div class="relative aspect-[4/3] overflow-hidden bg-slate-100">
            <?php if($property->image_path): ?>
                <img src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($property->image_path)); ?>"
                     alt="<?php echo e($property->name); ?>"
                     loading="lazy"
                     class="h-full w-full object-cover transition duration-500 group-hover:scale-105">
            <?php else: ?>
                <div class="flex h-full items-center justify-center text-sm text-slate-400">Foto kost belum tersedia</div>
            <?php endif; ?>

            <span class="absolute left-3 top-3 rounded-md bg-white px-3 py-1 text-xs font-medium capitalize text-slate-700 shadow-sm">
                <?php echo e($property->gender_type); ?>

            </span>
        </div>

        <div class="p-4">
            <div class="mb-2 flex items-start justify-between gap-2">
                <h3 class="font-semibold text-slate-800 transition group-hover:text-blue-900"><?php echo e($property->name); ?></h3>
                <span class="shrink-0 rounded-full bg-green-50 px-2 py-1 text-xs text-green-700">Lihat pilihan kamar</span>
            </div>

            <p class="mb-3 line-clamp-2 text-sm text-slate-500"><?php echo e($property->address); ?></p>

            <div class="mb-4 text-xs text-slate-500">
                <?php echo e(number_format((float) $property->distance, 2, ',', '.')); ?> km dari kampus
            </div>

            <div class="flex items-center justify-between border-t border-slate-100 pt-3">
                <div>
                    <p class="text-xs text-slate-400">Mulai dari</p>
                    <p class="font-semibold text-blue-900">
                        Rp<?php echo e(number_format((float) $property->starting_price, 0, ',', '.')); ?>

                        <span class="text-xs font-normal text-slate-500">/ bulan</span>
                    </p>
                </div>
                <span class="text-sm font-medium text-blue-900">Lihat detail →</span>
            </div>
        </div>
    </a>
</div>
<?php /**PATH D:\Development\nesaKost2\resources\views\components\layouts\guest\property-card.blade.php ENDPATH**/ ?>