<?php $__env->startSection('main'); ?>

<div class="space-y-6 text-slate-800">
    <section class="rounded-xl bg-white p-6 shadow-sm">
        <p class="text-sm text-slate-500"><a href="<?php echo e(route('owner.branches.index')); ?>" class="hover:text-blue-800">Data Cabang Kos</a> / <a href="<?php echo e(route('owner.branches.show', $branch)); ?>" class="hover:text-blue-800"><?php echo e($branch->name); ?></a> / <span class="font-semibold text-blue-800">Edit Cabang Kos</span></p>
        <h1 class="mt-3 text-3xl font-bold">Edit Cabang Kos</h1>
        <p class="mt-2 text-sm text-slate-500">Perbarui lokasi properti dan informasi operasional cabang kos yang dipilih.</p>
    </section>

    <?php echo $__env->make('pages.owner.branches.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="grid gap-4 rounded-xl bg-white p-6 shadow-sm md:grid-cols-[1fr_auto] md:items-center">
        <div>
            <div class="flex flex-wrap items-center gap-2">
                <h2 class="text-xl font-bold"><?php echo e($branch->name); ?></h2>
                <span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800"><?php echo e($branch->status === 'active' ? 'Aktif Beroperasi' : 'Nonaktif'); ?></span>
            </div>
            <p class="mt-2 text-sm text-slate-500"><span class="font-semibold text-blue-800"><?php echo e($branch->branch_code); ?></span> · Terdaftar sejak <?php echo e($branch->created_at?->format('d M Y') ?? '—'); ?></p>
            <p class="mt-1 text-sm text-slate-600">Pemilik: <?php echo e(trim(($branch->owner->user->fname ?? '') . ' ' . ($branch->owner->user->lname ?? ''))); ?></p>
        </div>
        <div class="grid grid-cols-2 gap-3 rounded-xl bg-indigo-50 p-4">
            <div><p class="text-xs uppercase tracking-wide text-slate-500">Kapasitas kamar</p><p class="mt-1 text-xl font-bold"><?php echo e($totalRooms); ?> <span class="text-sm font-medium">kamar</span></p></div>
            <div><p class="text-xs uppercase tracking-wide text-slate-500">Tingkat okupansi</p><p class="mt-1 text-xl font-bold"><?php echo e($totalRooms ? round($occupiedRooms / $totalRooms * 100) : 0); ?>%</p></div>
        </div>
    </section>

    <form method="POST" action="<?php echo e(route('owner.branches.update', $branch)); ?>" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <section class="space-y-6 rounded-xl bg-white p-6 shadow-sm md:p-8">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <h2 class="text-lg font-bold">Spesifikasi Formulir Entitas</h2>
                <span class="rounded-md bg-indigo-50 px-3 py-2 text-xs font-semibold text-blue-900">Entitas target: branch_dorm</span>
            </div>
            <div class="rounded-xl bg-blue-50 p-4 text-sm text-slate-600">
                <p class="font-semibold text-slate-800">Informasi integritas relasi basis data</p>
                <p class="mt-1">Kapasitas dihitung dari data kamar yang terdaftar. Mengubah informasi cabang tidak menghapus kamar atau transaksi yang sudah terhubung.</p>
            </div>
            <?php echo $__env->make('pages.owner.branches.partials.fields', ['owner' => $branch->owner, 'selectedFacilities' => $selectedFacilities], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="rounded-lg bg-slate-50 px-4 py-3 text-xs text-slate-500">Terakhir diperbarui <?php echo e($branch->updated_at?->format('d M Y, H:i') ?? '—'); ?></div>
        </section>
        <section class="flex justify-end gap-3 rounded-xl bg-white p-4 shadow-sm">
            <a href="<?php echo e(route('owner.branches.show', $branch)); ?>" class="rounded-lg bg-slate-100 px-5 py-3 text-sm font-semibold hover:bg-slate-200">Batal</a>
            <button type="submit" class="rounded-lg bg-blue-900 px-6 py-3 text-sm font-semibold text-white hover:bg-blue-800">Simpan Perubahan</button>
        </section>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.owner.container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\nesaKost2\resources\views\pages\owner\branches\edit.blade.php ENDPATH**/ ?>