<?php $__env->startSection('title', 'Detail Booking - nesaKost'); ?>

<?php $__env->startSection('content'); ?>
    <section class="min-h-screen bg-slate-50 py-12">
        <div class="mx-auto max-w-3xl px-6">

            <div class="rounded-2xl border border-slate-200 bg-white p-6 md:p-8">

                <h1 class="text-2xl font-semibold text-slate-900">
                    Detail Booking
                </h1>

                <p class="mt-2 text-sm text-slate-500">
                    Informasi booking dan status pembayaran kamu.
                </p>

                <?php if(session('success')): ?>
                    <div class="mt-5 rounded-lg bg-green-50 p-4 text-sm text-green-700">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="mt-5 rounded-lg bg-red-50 p-4 text-sm text-red-700">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <?php
                    $latestPayment = $booking->payments->sortByDesc('id')->first();

                    $bookingStatus =
                        [
                            'pending_payment' => 'Menunggu Pembayaran',
                            'confirmed' => 'Dikonfirmasi',
                            'expired' => 'Kedaluwarsa',
                            'cancelled' => 'Dibatalkan',
                            'cancelled' => 'Dibatalkan',
                        ][$booking->status] ?? $booking->status;

                    $paymentStatus =
                        [
                            'pending' => 'Menunggu Pembayaran',
                            'paid' => 'Berhasil',
                            'failed' => 'Gagal',
                            'expired' => 'Kedaluwarsa',
                            'cancelled' => 'Dibatalkan',
                        ][$latestPayment?->status] ?? 'Belum ada pembayaran';
                ?>

                
                <div class="mt-8 rounded-xl bg-slate-50 p-5">
                    <p class="text-xs text-slate-500">
                        Status Booking
                    </p>

                    <p class="mt-1 font-semibold text-slate-900">
                        <?php echo e($bookingStatus); ?>

                    </p>

                    <p class="mt-4 text-xs text-slate-500">
                        Status Pembayaran
                    </p>

                    <p class="mt-1 font-semibold text-slate-900">
                        <?php echo e($paymentStatus); ?>

                    </p>
                </div>

                
                <div class="mt-8 space-y-4">

                    <div class="flex justify-between gap-4">
                        <span class="text-sm text-slate-500">Kode Booking</span>
                        <span class="text-sm font-semibold text-slate-800">
                            <?php echo e($booking->booking_code); ?>

                        </span>
                    </div>

                    <div class="flex justify-between gap-4">
                        <span class="text-sm text-slate-500">Jenis Booking</span>
                        <span class="text-sm font-semibold text-slate-800">
                            <?php echo e($booking->booking_type === 'renewal' ? 'Perpanjangan Sewa' : 'Booking Baru'); ?>

                        </span>
                    </div>

                    <div class="flex justify-between gap-4">
                        <span class="text-sm text-slate-500">Kode Kamar</span>
                        <span class="text-sm font-semibold text-slate-800">
                            <?php echo e($booking->room->room_code); ?>

                        </span>
                    </div>

                    <div class="flex justify-between gap-4">
                        <span class="text-sm text-slate-500">Tanggal Mulai</span>
                        <span class="text-sm font-semibold text-slate-800">
                            <?php echo e($booking->start_date->format('d M Y')); ?>

                        </span>
                    </div>

                    <div class="flex justify-between gap-4">
                        <span class="text-sm text-slate-500">Tanggal Selesai</span>
                        <span class="text-sm font-semibold text-slate-800">
                            <?php echo e($booking->end_date->format('d M Y')); ?>

                        </span>
                    </div>

                    <div class="flex justify-between gap-4">
                        <span class="text-sm text-slate-500">Durasi</span>
                        <span class="text-sm font-semibold text-slate-800">
                            <?php echo e($booking->duration_month); ?> bulan
                        </span>
                    </div>

                    <div class="flex justify-between gap-4">
                        <span class="text-sm text-slate-500">Harga per Bulan</span>
                        <span class="text-sm font-semibold text-slate-800">
                            Rp<?php echo e(number_format((float) $booking->price_snapshot, 0, ',', '.')); ?>

                        </span>
                    </div>

                    <hr>

                    <div class="flex justify-between gap-4">
                        <span class="font-semibold text-slate-800">
                            Total Pembayaran
                        </span>
                        <span class="text-lg font-bold text-blue-900">
                            Rp<?php echo e(number_format((float) ($latestPayment?->amount ?? 0), 0, ',', '.')); ?>

                        </span>
                    </div>

                </div>

                
                <?php if($booking->status === 'pending_payment'): ?>
                    <?php if($booking->booking_type === 'renewal'): ?>
                        <div class="mt-6 rounded-lg border border-blue-100 bg-blue-50 p-4">
                            <p class="text-sm font-semibold text-blue-950">Batas pembayaran perpanjangan</p>
                            <p class="mt-1 text-sm text-blue-900">Selesaikan pembayaran paling lambat <?php echo e($booking->expires_at?->format('d M Y, H:i') ?? '-'); ?> WIB. Kamar ditahan selama periode ini.</p>
                        </div>
                    <?php endif; ?>
                    <div class="mt-8 space-y-3">
                        <a href="<?php echo e(route('tenant.bookings.payments.create', $booking->id)); ?>"
                            class="block w-full rounded-lg bg-blue-900 px-4 py-3 text-center text-sm font-semibold text-white transition hover:bg-blue-950">
                            <?php echo e($latestPayment && $latestPayment->status === 'pending' && $latestPayment->payment_method
                                ? 'Lihat / Ubah Metode Pembayaran'
                                : 'Pilih Metode Pembayaran'); ?>

                        </a>
                    </div>

                    
                <?php elseif($booking->status === 'cancelled'): ?>
                    <div class="mt-8 rounded-xl border border-red-200 bg-red-50 p-5">
                        <h2 class="font-semibold text-red-900">
                            Booking Dibatalkan
                        </h2>

                        <p class="mt-2 text-sm text-red-800">
                            Booking ini telah dibatalkan dan kamar sudah dilepaskan.
                        </p>

                        <?php if($booking->cancelled_at): ?>
                            <p class="mt-2 text-xs text-red-700">
                                Dibatalkan pada <?php echo e($booking->cancelled_at->format('d M Y H:i')); ?>

                            </p>
                        <?php endif; ?>

                        <?php if($booking->cancellation_reason): ?>
                            <p class="mt-3 text-sm text-red-800">
                                <strong>Alasan:</strong> <?php echo e($booking->cancellation_reason); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>


                
                <?php if($booking->status === 'confirmed' && $booking->rent): ?>
                    <div class="mt-8 rounded-xl border border-green-200 bg-green-50 p-5">
                        <h2 class="font-semibold text-green-800">
                            Pembayaran Berhasil
                        </h2>

                        <p class="mt-2 text-sm text-green-700">
                            Masa sewa berhasil dibuat.
                        </p>

                        <div class="mt-4 space-y-2 text-sm text-green-800">
                            <p>
                                Kode Rent:
                                <strong><?php echo e($booking->rent->rent_code); ?></strong>
                            </p>

                            <p>
                                Status Rent:
                                <strong><?php echo e(ucfirst($booking->rent->status)); ?></strong>
                            </p>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.guest.container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\nesaKost2\resources\views\pages\tenant\bookings\show.blade.php ENDPATH**/ ?>