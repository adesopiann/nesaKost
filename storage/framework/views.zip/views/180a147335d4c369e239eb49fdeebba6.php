<div class="space-y-6">
    <div class="grid gap-6 md:grid-cols-2">
        <div>
            <label for="room_code" class="mb-2 block text-sm font-semibold">Kode Kamar <span class="text-red-500">*</span></label>
            <input id="room_code" name="room_code" value="<?php echo e(old('room_code', $room->room_code ?? '')); ?>" required maxlength="20" placeholder="Contoh: KMR-A101" class="w-full rounded-lg border border-slate-200 px-4 py-3 text-sm focus:border-blue-500 focus:outline-none">
            <?php $__errorArgs = ['room_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <p class="mt-2 text-xs text-slate-500">Kode kamar diisi manual dan harus unik.</p>
        </div>
        <div>
            <label for="status" class="mb-2 block text-sm font-semibold">Status Kamar <span class="text-red-500">*</span></label>
            <?php ($selectedStatus = old('status', $room->status ?? 'available')); ?>
            <select id="status" name="status" required class="w-full rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none">
                <option value="available" <?php if($selectedStatus === 'available'): echo 'selected'; endif; ?>>Tersedia</option>
                <option value="occupied" <?php if($selectedStatus === 'occupied'): echo 'selected'; endif; ?>>Terisi</option>
                <option value="maintenance" <?php if($selectedStatus === 'maintenance'): echo 'selected'; endif; ?>>Dalam perawatan</option>
                <option value="inactive" <?php if($selectedStatus === 'inactive'): echo 'selected'; endif; ?>>Nonaktif</option>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div>
        <label for="branch_dorm_id" class="mb-2 block text-sm font-semibold">Cabang Kos <span class="text-red-500">*</span></label>
        <select id="branch_dorm_id" name="branch_dorm_id" required class="w-full rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm focus:border-blue-500 focus:outline-none">
            <option value="">Pilih cabang kos</option>
            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($branch->id); ?>" <?php if((string) old('branch_dorm_id', $room->branch_dorm_id ?? '') === (string) $branch->id): echo 'selected'; endif; ?>><?php echo e($branch->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['branch_dorm_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php if($branches->isEmpty()): ?><p class="mt-2 text-xs text-amber-700">Belum ada cabang yang dapat dipilih. Tambahkan cabang terlebih dahulu.</p><?php endif; ?>
    </div>

    <div class="grid gap-6 md:grid-cols-2">
        <div>
            <label for="type" class="mb-2 block text-sm font-semibold">Tipe Kamar <span class="text-red-500">*</span></label>
            <input id="type" name="type" value="<?php echo e(old('type', $room->type ?? '')); ?>" required maxlength="50" placeholder="Contoh: Standard, Deluxe, Single" class="w-full rounded-lg border border-slate-200 px-4 py-3 text-sm focus:border-blue-500 focus:outline-none">
            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="monthly_price" class="mb-2 block text-sm font-semibold">Harga Sewa per Bulan (Rp) <span class="text-red-500">*</span></label>
            <input id="monthly_price" name="monthly_price" type="number" min="0" step="0.01" value="<?php echo e(old('monthly_price', $room->monthly_price ?? '')); ?>" required placeholder="Contoh: 850000" class="w-full rounded-lg border border-slate-200 px-4 py-3 text-sm focus:border-blue-500 focus:outline-none">
            <?php $__errorArgs = ['monthly_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div>
        <label for="images" class="mb-2 block text-sm font-semibold">Galeri Foto Kamar</label>
        <input id="images" name="images[]" type="file" multiple accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="w-full rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm">
        <p class="mt-2 text-xs text-slate-500">Pilih beberapa foto sekaligus. Format JPG, PNG, atau WebP; maksimal 10 foto per unggahan dan 5 MB per foto.</p>
        <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if(isset($room) && $room && $room->images->isNotEmpty()): ?>
            <div class="mt-5">
                <p class="mb-3 text-sm font-semibold">Foto yang sudah tersimpan</p>
                <div class="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                    <?php $__currentLoopData = $room->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="overflow-hidden rounded-xl border border-slate-200 p-2">
                            <img src="<?php echo e(asset('storage/'.$image->image_path)); ?>" alt="Foto kamar <?php echo e($room->room_code); ?>" class="h-32 w-full rounded-lg object-cover">
                            <span class="mt-2 flex items-center gap-2 text-xs">
                                <input type="checkbox" name="delete_images[]" value="<?php echo e($image->id); ?>" class="rounded border-slate-300 text-red-600">
                                Hapus foto ini
                            </span>
                            <?php if($image->is_primary): ?>
                                <span class="mt-2 inline-block rounded-full bg-blue-100 px-2 py-1 text-xs font-semibold text-blue-800">Foto utama</span>
                            <?php endif; ?>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="mt-2 text-xs text-slate-500">Centang foto yang ingin dihapus, lalu simpan perubahan.</p>
            </div>
        <?php elseif(isset($room) && $room && $room->image_path): ?>
            <div class="mt-3">
                <p class="mb-2 text-xs font-semibold text-slate-500">Foto lama (belum dipindahkan ke galeri)</p>
                <img src="<?php echo e(asset('storage/'.$room->image_path)); ?>" alt="Foto kamar <?php echo e($room->room_code); ?>" class="h-40 w-56 rounded-lg object-cover">
            </div>
        <?php endif; ?>
    </div>

    <div>
        <label for="description" class="mb-2 block text-sm font-semibold">Deskripsi Kamar</label>
        <textarea id="description" name="description" rows="4" placeholder="Jelaskan fasilitas atau kondisi kamar..." class="w-full rounded-lg border border-slate-200 px-4 py-3 text-sm focus:border-blue-500 focus:outline-none"><?php echo e(old('description', $room->description ?? '')); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH D:\Development\nesaKost2\resources\views\pages\owner\rooms\partials\fields.blade.php ENDPATH**/ ?>